﻿using System;
using System.Collections.Generic;

namespace DoctorDiary.DataAccessLayer.Models
{
    public partial class Hospital
    {
        public string HospitalId { get; set; }
        public string HospitalName { get; set; }
        public string HospitalAddress { get; set; }
        public string City { get; set; }
        public decimal Pincode { get; set; }
        public string Contact { get; set; }
    }
}
