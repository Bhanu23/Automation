﻿using System;
using System.Collections.Generic;

namespace DoctorDiary.DataAccessLayer.Models
{
    public partial class Feedback
    {
        public string DoctorId { get; set; }
        public string PatientId { get; set; }
        public string Feedback1 { get; set; }
        public decimal? Rating { get; set; }

        public Doctor Doctor { get; set; }
        public Patient Patient { get; set; }
    }
}
