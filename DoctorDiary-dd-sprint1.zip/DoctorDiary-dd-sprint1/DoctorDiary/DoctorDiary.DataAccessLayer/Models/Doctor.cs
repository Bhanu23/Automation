﻿using System;
using System.Collections.Generic;

namespace DoctorDiary.DataAccessLayer.Models
{
    public partial class Doctor
    {
        public Doctor()
        {
            Appointment = new HashSet<Appointment>();
            Detail = new HashSet<Detail>();
            Feedback = new HashSet<Feedback>();
            Prescription = new HashSet<Prescription>();
        }

        public string DoctorId { get; set; }
        public string DoctorName { get; set; }
        public string Gender { get; set; }
        public string EmailId { get; set; }
        public DateTime Dob { get; set; }
        public string HospitalId { get; set; }
        public string SpecializationName { get; set; }
        public string MorningSlot { get; set; }
        public string EveningSlot { get; set; }
        public string LicenseId { get; set; }
        public int? Experience { get; set; }

        public License License { get; set; }
        public ICollection<Appointment> Appointment { get; set; }
        public ICollection<Detail> Detail { get; set; }
        public ICollection<Feedback> Feedback { get; set; }
        public ICollection<Prescription> Prescription { get; set; }
    }
}
