﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using DoctorDiary.DataAccessLayer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DoctorDiaryWebServices.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class LicenseController : ControllerBase
    {
        DoctorDiaryRepository _repository;
        IMapper _mapper;
        public LicenseController(DoctorDiaryRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }
        // GET: api/License
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/License/5
        [HttpGet]
        public JsonResult GetLicense(string licenseId)
        {
            Models.License obj = null;
            try
            {
                var obj1 = _repository.GetLicenses(licenseId);
                obj = _mapper.Map<Models.License>(obj1);
            }
            catch (Exception ex)
            {

                obj = null;
            }

            return new JsonResult(obj);
        }

        // POST: api/License
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT: api/License/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
