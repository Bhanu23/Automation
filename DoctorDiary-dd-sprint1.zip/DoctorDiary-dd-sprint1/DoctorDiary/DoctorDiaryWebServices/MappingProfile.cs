﻿using AutoMapper;
using DoctorDiary.DataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DoctorDiaryWebServices
{
    public class MappingProfile: Profile
    {
        public MappingProfile()
        {
            CreateMap<License, Models.License>();
        }
    }
}
