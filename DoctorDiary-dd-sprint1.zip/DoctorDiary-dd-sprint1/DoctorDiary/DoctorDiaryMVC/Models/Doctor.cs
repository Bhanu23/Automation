﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DoctorDiaryMVC.Models
{
    public class Doctor
    {
        public string DoctorId { get; set; }
        public string DoctorName { get; set; }
        public string Gender { get; set; }
        public string EmailId { get; set; }
        public DateTime Dob { get; set; }
        public string HospitalId { get; set; }
        public string SpecializationName { get; set; }
        public string MorningSlot { get; set; }
        public string EveningSlot { get; set; }
        public string LicenseId { get; set; }
        public int? Experience { get; set; }
    }
}
