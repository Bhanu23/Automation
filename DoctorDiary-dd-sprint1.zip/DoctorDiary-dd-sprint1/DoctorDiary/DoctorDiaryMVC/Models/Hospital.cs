﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DoctorDiaryMVC.Models
{
    public class Hospital
    {
        public string HospitalId { get; set; }
        public string HospitalName { get; set; }
    }
}
