﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace DoctorDiaryMVC.Models
{
    public class SearchDoctor
    {
        public string DoctorId { get; set; }
        [DisplayName("Doctor Name")]
        public string DoctorName { get; set; }
        [DisplayName("Specialization Name")]
        public string SpecializationName { get; set; }
        [DisplayName("Experience")]
        public int? Experience { get; set; }
        [DisplayName("Hospital Name")]
        public string HospitalName { get; set; }
        [DisplayName("Location")]
        public string Location { get; set; }
        [DisplayName("Rating")]
        public decimal? Rating { get; set; }
    }
}
