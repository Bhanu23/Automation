﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DoctorDiaryMVC.Models
{
    public class License
    {
        public string LicenseId { get; set; }
        public string DoctorName { get; set; }
        public string Degree { get; set; }
        public string Gender { get; set; }
        public string SpecializationName { get; set; }
        public DateTime Dob { get; set; }
        public DateTime Lid { get; set; }
    }
}
