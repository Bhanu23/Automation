﻿using AutoMapper;
using DoctorDiary.DataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DoctorDiaryMVC.Repository
{
    public class MappingProfile:Profile
    {
        public MappingProfile()
        {
            CreateMap<Models.Doctor, Doctor>();
            CreateMap<Doctor, Models.Doctor>();
            CreateMap<Patient, Models.Patient>();
            CreateMap<Appointment, Models.Appointment>();
        }
    }
}
