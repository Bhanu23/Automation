﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using DoctorDiary.DataAccessLayer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DoctorDiaryMVC.Controllers
{
    public class PatientController : Controller
    {
        DoctorDiaryRepository repository;
        IMapper mapper;
        public PatientController(DoctorDiaryRepository repository, IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }
        public IActionResult Home()
        {
            try
            {
                if (HttpContext.Session.GetString("email") == null)
                    return RedirectToAction("Login", "Home");
                return View();
            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        public IActionResult PatientDetails()
        {
            if (HttpContext.Session.GetString("email") == null)
                return RedirectToAction("Login", "Home");
            var emailId = HttpContext.Session.GetString("email");
            var patient = repository.GetPatientDetails(emailId);
            return View(mapper.Map<Models.Patient>(patient));
        }

        public IActionResult UpdatePatientDetails(Models.Patient patient, IFormCollection frm)
        {
            try
            {
                if (HttpContext.Session.GetString("email") == null)
                    return RedirectToAction("Login", "Home");
                var status = repository.UpdatePatientDetail(patient.PatientId, frm["Contact"]);
                if (status)
                {
                    TempData["Message"] = "Update";
                    return View("Home");
                }
                else
                    return View("Error");
            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        public IActionResult BookAppointment(string specializationName)
        {
            try
            {
                if (HttpContext.Session.GetString("email") == null)
                    return RedirectToAction("Login", "Home");
                List<string> specialization = repository.GetSpecialization();
                ViewBag.Specialization = specialization;
                List<Models.SearchDoctor> list = new List<Models.SearchDoctor>();
                var doctors = repository.GetDoctor(specializationName);
                foreach (var item in doctors)
                {
                    list.Add(new Models.SearchDoctor
                    {
                        DoctorId = item.DoctorId,
                        DoctorName = item.DoctorName,
                        SpecializationName = item.SpecializationName,
                        Experience = item.Experience,
                        HospitalName = repository.GetHospitalName(item.HospitalId),
                        Location = repository.Location(item.HospitalId),
                        Rating = repository.GetRatings(item.DoctorId)
                    });
                }
                return View(list);
            }
            catch (Exception)
            {

                throw;
            }

        }
        public IActionResult PatientBookAppointment(Models.SearchDoctor doctor, IFormCollection frm)
        {
            try
            {
                if (HttpContext.Session.GetString("email") == null)
                    return RedirectToAction("Login", "Home");
                ArrayList list = repository.GetHospitalAddressPhone(doctor.HospitalName);
                ViewBag.Message = list;
                int day = (int)DateTime.Now.DayOfWeek;
                List<string> dates = new List<string>();
                if (day>=1 && day <= 5)
                {
                    int diff = 5 - day;
                    for (double a = 0; a <= diff; a++)
                    {

                        if (diff == 0)
                        {
                            dates.Add(DateTime.Now.Date.AddDays(a).ToString("dd/MM/yyyy"));
                          
                        }
                        else
                        {
                            dates.Add(DateTime.Now.Date.AddDays(a).ToString("dd/MM/yyyy"));
                        }

                    }
                }
                else if(day==6)
                {
                    //dates.Add(DateTime.Now.Date.AddDays(2).ToString("dd/MM/yyyy"));
                    ViewBag.Alert = "** Bookings are only available from Sunday till Friday ";
                    ViewBag.Dates = dates;
                    return View(doctor);
                }
                else
                {
                    for (int i = 0; i <5; i++)
                    {
                        dates.Add(DateTime.Now.Date.AddDays(i+1).ToString("dd/MM/yyyy"));
                    }
                    
                }
                ViewBag.Dates = dates;
                string date = frm["dates"];
                if (date == DateTime.Now.Date.ToString("dd/MM/yyyy"))
                {
                    int Time = Convert.ToInt32((DateTime.Now.ToString().Split(' ')[1]).Split(':')[0]);
                    if (Time >= 1 && Time <= 11 && DateTime.Now.ToString().Split(' ')[2] == "PM")
                    {
                        Time = Time + 12;
                    }


                    ViewBag.Time = Time;

                }
                else
                {
                    ViewBag.Time = null;
                }
                List<string> slots = repository.GetAppointmentSlotsForDoctor(doctor.DoctorId, date);
                ViewBag.BookedSlots = slots;
                ViewBag.SelectedDate = date;
                ViewBag.Slots = repository.GetDoctorSlotBydoctorId(doctor.DoctorId);
                return View(doctor);

            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        public IActionResult SavePatientBookAppointment(string doctorId, IFormCollection frm)
        {
            try
            {

                string email = HttpContext.Session.GetString("email");
                DateTime date = DateTime.ParseExact(frm["date"], "dd/MM/yyyy", null);
                string slot = frm["slot"];
                if (HttpContext.Session.GetString("email") == null)
                    return RedirectToAction("Login", "Home");
                string patientId = repository.GetPatientId(email);
                string Appointmentstatus = "Pending";
                var status = repository.AddAppointment(patientId, doctorId, slot, date,Appointmentstatus);
                if (status)
                {
                    TempData["Message"] = "Booked";
                    return View("Home");
                }
                else
                {
                    TempData["Message"] = "tryagain";
                    return Redirect("BookAppointment");
                }

            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        public IActionResult MyAppointments()
        {
            try
            {
                
                List<Models.Appointment> propernewlist = new List<Models.Appointment>();
                string email = HttpContext.Session.GetString("email");
                string patientId = repository.GetPatientId(email);
                var newlist=repository.GetAppointmentsByPatientId(patientId);
                foreach (var item in newlist)
                {
                    int slot = Convert.ToInt32(item.AppointmentSlot[1].ToString());
                    int time=Convert.ToInt32((DateTime.Now.ToString().Split(' ')[1]).Split(':')[0]+(DateTime.Now.ToString().Split(' ')[1]).Split(':')[1]);
                    string ampm = DateTime.Now.ToString().Split(' ')[2];
                    DateTime date = item.Date.Date;
                    DateTime today = DateTime.Today.Date;
                    if (date<today && item.Status=="Pending"  )
                    {
                        var status=repository.UpdateAppointmentStatus(item.AppointmentId,"Not Attended");
                        if (!status)
                        {
                            
                        }
                    }
                    else if (item.Date.Date==DateTime.Now.Date && item.Status == "Pending" && ampm == "Pm" && time > 100 && slot >= 9 && slot <= 12)
                    {
                        var status = repository.UpdateAppointmentStatus(item.AppointmentId,"Not Attended");
                        if (!status)
                        {

                        }
                    }
                    else if(item.Date.Date == DateTime.Now.Date && item.Status == "Pending" && ampm == "Pm" && time > 1000 && time < 1200 && slot >= 5 && slot <= 9)
                    {
                        var status = repository.UpdateAppointmentStatus(item.AppointmentId,"Not Attended");
                        if (!status)
                        {

                        }
                    }
                }
                foreach (var item in newlist)
                {
                    Models.Appointment obj = new Models.Appointment();
                    obj.AppointmentId = item.AppointmentId;
                    string slot = item.AppointmentSlot;
                    int sub =Convert.ToInt32(slot[0].ToString()+slot[1].ToString());
                    if(sub==2)
                        obj.AppointmentSlot = slot.Substring(0, 2) + ":" + slot.Substring(2, 2)+" PM";
                    else if(sub<9)
                        obj.AppointmentSlot = slot.Substring(0, 2) + ":" + slot.Substring(2, 2) + " PM";
                    else
                        obj.AppointmentSlot = slot.Substring(0, 2) + ":" + slot.Substring(2, 2) + " AM";
                    //obj.Date = DateTime.ParseExact(item.Date.ToString().Split(' ')[0],"dd/MM/yyyy", null);
                    obj.Date = item.Date.Date.ToString("dd/MM/yyyy");
                    obj.DoctorId = item.DoctorId;
                    obj.PatientId = item.PatientId;
                    obj.Status = item.Status;
                    var doctor = repository.GetDoctorByDoctorId(item.DoctorId);
                    obj.Name = doctor.DoctorName;
                    propernewlist.Add(obj);
                }
                return View(propernewlist);
            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        //Cancel Appointment
        public IActionResult CancelAppointment(string appointmentId)
        {
            try
            {
                var status=repository.CancelAppointment(appointmentId);
                if (status)
                {
                    return Redirect("MyAppointments");
                }
                else
                    return View("Error");
            }
            catch (Exception)
            {

                throw;
            }
        }
        public IActionResult BookRefrencedDoctor()
        {
            try
            {
                string patientId=repository.GetPatientId(HttpContext.Session.GetString("email"));
                var doctors = repository.GetRefrencedDoctorList(patientId);
                List<Models.SearchDoctor> list = new List<Models.SearchDoctor>();
                foreach (var item in doctors)
                {
                    list.Add(new Models.SearchDoctor
                    {
                        DoctorId = item.DoctorId,
                        DoctorName = item.DoctorName,
                        SpecializationName = item.SpecializationName,
                        Experience = item.Experience,
                        HospitalName = repository.GetHospitalName(item.HospitalId),
                        Location = repository.Location(item.HospitalId),
                        Rating = repository.GetRatings(item.DoctorId)
                    });
                }
                return View(list);
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}