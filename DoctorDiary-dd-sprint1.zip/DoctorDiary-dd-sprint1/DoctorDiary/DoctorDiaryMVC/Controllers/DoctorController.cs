﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using AutoMapper;
using DoctorDiary.DataAccessLayer;
using DoctorDiaryMVC.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace DoctorDiaryMVC.Controllers
{
    public class DoctorController : Controller
    {
        public static List<string> medList = new List<string>();
        DoctorDiaryRepository repository;
        IMapper mapper;
        public DoctorController(DoctorDiaryRepository repository, IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }
        public IActionResult Home()
        {
            try
            {
                if (HttpContext.Session.GetString("email") == null)
                    return RedirectToAction("Login", "Home");
                return View();
            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        public IActionResult DoctorDetails()
        {
            try
            {
                var emailId = HttpContext.Session.GetString("email");
                if (emailId == null)
                    return RedirectToAction("Login", "Home");
                ViewBag.Slots = repository.GetDoctorSlot(emailId);
                var doctor = repository.GetDoctorDetails(emailId);
                return View(mapper.Map<Models.Doctor>(doctor));
            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        public IActionResult UpdateDoctorDetails(Models.Doctor doc, IFormCollection frm)
        {
            try
            {
                var emailId = HttpContext.Session.GetString("email");
                List<string> slots = repository.GetDoctorSlot(emailId);
                if (DateTime.Now.DayOfWeek.ToString() == "Saturday" || slots.Count == 0 || slots.Count == 1)
                {
                    var status = repository.UpdateDoctorDetail(doc.DoctorId, frm["morslot"], frm["eveslot"]);
                    if (status)
                    {
                        TempData["Message"] = "Update";
                        return Redirect("Home");
                    }
                    else
                        return View("Error");
                }
                else
                {
                    TempData["Message"] = "day";
                    return Redirect("DoctorDetails");
                }

            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        public IActionResult MyAppointments()
        {
            try
            {
                if (HttpContext.Session.GetString("email") == null)
                    return RedirectToAction("Login", "Home");
                medList = new List<string>();
                List<Models.Appointment> propernewlist = new List<Models.Appointment>();
                string email = HttpContext.Session.GetString("email");
                string doctorId = repository.GetDoctorId(email);
                var newlist = repository.GetAppointmentsByDoctorId(doctorId, DateTime.Now.Date);
                foreach (var item in newlist)
                {
                    int slot = Convert.ToInt32(item.AppointmentSlot[1].ToString());
                    int time = Convert.ToInt32((DateTime.Now.ToString().Split(' ')[1]).Split(':')[0] + (DateTime.Now.ToString().Split(' ')[1]).Split(':')[1]);
                    string ampm = DateTime.Now.ToString().Split(' ')[2];
                    DateTime date = item.Date.Date;
                    DateTime today = DateTime.Now.Date;
                    if (date < today && item.Status == "Pending")
                    {
                        var status = repository.UpdateAppointmentStatus(item.AppointmentId, "Not Attended");
                        if (!status)
                        {

                        }
                    }
                    if (item.Date.Date == DateTime.Now.Date && item.Status == "Pending" && ampm == "PM" && time > 100 && slot >= 9 && slot <= 12)
                    {
                        var status = repository.UpdateAppointmentStatus(item.AppointmentId, "Not Attended");
                        if (!status)
                        {

                        }
                    }
                    if (item.Date.Date == DateTime.Now.Date && item.Status == "Pending" && ampm == "PM" && time > 1000 && time < 1200 && slot >= 5 && slot <= 9)
                    {
                        var status = repository.UpdateAppointmentStatus(item.AppointmentId, "Not Attended");
                        if (!status)
                        {

                        }
                    }
                }
                foreach (var item in newlist)
                {
                    Models.Appointment obj = new Models.Appointment();
                    obj.AppointmentId = item.AppointmentId;
                    string slot = item.AppointmentSlot;
                    int sub = Convert.ToInt32(slot[1].ToString());
                    if (sub == 2)
                        obj.AppointmentSlot = slot.Substring(0, 2) + ":" + slot.Substring(2, 2) + " PM";
                    else if (sub < 9)
                        obj.AppointmentSlot = slot.Substring(0, 2) + ":" + slot.Substring(2, 2) + " PM";
                    else
                        obj.AppointmentSlot = slot.Substring(0, 2) + ":" + slot.Substring(2, 2) + " AM";
                    //obj.Date = DateTime.ParseExact(item.Date.ToString().Split(' ')[0],"dd/MM/yyyy", null);
                    obj.Date = item.Date.Date.ToString("dd/MM/yyyy");
                    obj.DoctorId = item.DoctorId;
                    obj.PatientId = item.PatientId;
                    obj.Status = item.Status;
                    var patient = repository.GetPatient(item.PatientId);
                    obj.Name = patient.PatientName;
                    propernewlist.Add(obj);
                }
                return View(propernewlist);
            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        //Cancel Appointment
        public IActionResult CancelAppointment(string appointmentId)
        {
            try
            {
                var status = repository.CancelAppointment(appointmentId);
                if (status)
                {
                    return Redirect("MyAppointments");
                }
                else
                    return View("Error");
            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        //Prescription
        public IActionResult Prescription(string patientId, string appointmentId, IFormCollection frm)
        {
            try
            {
                if (HttpContext.Session.GetString("email") == null)
                    return RedirectToAction("Login", "Home");
                if (patientId != null)
                {
                    var patient = repository.GetPatient(patientId);
                    string patientName = patient.PatientName;
                    int age = patient.Age;
                    string gender = patient.Gender;
                    if (gender == "M")
                        HttpContext.Session.SetString("gender", "Male");
                    else if (gender == "F")
                        HttpContext.Session.SetString("gender", "Female");
                    else
                        HttpContext.Session.SetString("gender", "Others");
                    HttpContext.Session.SetString("patientName", patientName);
                    HttpContext.Session.SetInt32("age", age);
                    HttpContext.Session.SetString("patientId", patientId);
                    HttpContext.Session.SetString("appointmentId", appointmentId);
                }
                var dict = repository.GetRefrenceDoctorList();
                List<Models.Refrence> list = new List<Models.Refrence>();
                foreach (var item in dict)
                {
                    Models.Refrence obj = new Models.Refrence();
                    obj.DoctorId = item.Key;
                    obj.DoctorName = item.Value;
                    list.Add(obj);
                }
                ViewBag.RefDoctors = list;
                ViewBag.medNames = repository.GetMedicinesName();
                string medName = frm["med"];
                string mor = " ";
                string noon = " ";
                string eve = " ";
                if (frm["morning"] == "ON")
                {
                    mor = "Morning";
                }

                if (frm["afternoon"] == "ON")
                {
                    noon = "Afternoon";
                }
                if (frm["evening"] == "ON")
                {
                    eve = "Evening";
                }
                string food = frm["food"];
                string medinfo = medName + "-" + mor + "-" + noon + "-" + eve + "-" + food;
                if (!medList.Contains(medinfo) && food != null && medinfo != null)
                {
                    medList.Add(medinfo);
                }
                if (medList == null)
                    ViewBag.medinfo = " ";
                else
                    ViewBag.medinfo = medList;

                return View();
            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        public IActionResult SavePrescription(IFormCollection frm)
        {
            try
            {
                if (HttpContext.Session.GetString("email") == null)
                    return RedirectToAction("Login", "Home");
                string patientId = HttpContext.Session.GetString("patientId");
                string doctorId = repository.GetDoctorId(HttpContext.Session.GetString("email"));
                List<string> medNames = new List<string>();
                List<string> slot = new List<string>();
                foreach (var item in medList)
                {
                    var splitList = item.Split('-');
                    medNames.Add(splitList[0] + "-" + splitList[1]);
                    slot.Add(splitList[2] + "," + splitList[3] + "," + splitList[4] + "," + splitList[5]);
                }
                string appointmentId = HttpContext.Session.GetString("appointmentId");
                byte validity = Convert.ToByte(frm["validity"]);
                string remarks = frm["remark"];
                string referenceddoctorId = frm["ref"];

                bool status = repository.AddPrescription(patientId, doctorId, medNames, slot, appointmentId, validity);
                string medicine = "";
                foreach (var item in medList)
                {
                    medicine += item + ",";
                }
                if (referenceddoctorId == "")
                    referenceddoctorId = "-N/A-";
                bool status1 = repository.AddDetail(patientId, doctorId, remarks, medicine.Substring(0, medicine.Length - 1), appointmentId, referenceddoctorId);
                if (status && status1)
                {
                    medList = new List<string>();
                    repository.UpdateAppointmentStatus(HttpContext.Session.GetString("appointmentId"), "Attended");
                    return Redirect("MyAppointments");
                }
                else
                {
                    return View("Error");
                }

            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        public IActionResult PatientDetails(string patientId)
        {
            try
            {
                var patient = repository.GetPatient(patientId);
                ViewBag.Name = patient.PatientName;
                ViewBag.Age = patient.Age;
                if (patient.Gender == "M")
                    ViewBag.Gender = "Male";
                else if (patient.Gender == "F")
                    ViewBag.Gender = "Female";
                else
                    ViewBag.Gender = "Others";
                var detailsOfPatient = repository.GetDetailsByPatientId(patientId);
                List<string> remarks = new List<string>();
                List<string> medicines = new List<string>();
                int a = 1;
                foreach (var item in detailsOfPatient)
                {
                    remarks.Add(item.Remark);
                    var medicineList = item.Meds.Split(',');
                    int aski = 97;
                    foreach (var medicine in medicineList)
                    {
                        string integer = Convert.ToString(a) + ((char)aski).ToString()+" : "+medicine;
                        medicines.Add(integer);
                        aski++;
                    }
                    a++;
                }
                ViewBag.Remarks = remarks;
                ViewBag.Medicines = medicines;
                return View();
            }
            catch (Exception)
            {

                return View("Error");
            }

        }
    }
}