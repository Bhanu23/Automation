﻿using System;
using System.Collections.Generic;

namespace DoctorDiary.DataAccessLayer.Models
{
    public partial class License
    {
        public License()
        {
            Doctor = new HashSet<Doctor>();
        }

        public string LicenseId { get; set; }
        public string DoctorName { get; set; }
        public string Degree { get; set; }
        public string Gender { get; set; }
        public string SpecializationName { get; set; }
        public DateTime Dob { get; set; }
        public DateTime Lid { get; set; }

        public ICollection<Doctor> Doctor { get; set; }
    }
}
