﻿using System;
using System.Collections.Generic;

namespace DoctorDiary.DataAccessLayer.Models
{
    public partial class Appointment
    {
        public Appointment()
        {
            Detail = new HashSet<Detail>();
            Prescription = new HashSet<Prescription>();
        }

        public string AppointmentId { get; set; }
        public string DoctorId { get; set; }
        public string PatientId { get; set; }
        public string AppointmentSlot { get; set; }
        public DateTime Date { get; set; }
        public string Status { get; set; }

        public Doctor Doctor { get; set; }
        public Patient Patient { get; set; }
        public ICollection<Detail> Detail { get; set; }
        public ICollection<Prescription> Prescription { get; set; }
    }
}
