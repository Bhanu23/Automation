﻿using System;
using System.Collections.Generic;

namespace DoctorDiary.DataAccessLayer.Models
{
    public partial class Medicine
    {
        public string MedicineId { get; set; }
        public string MedicineName { get; set; }
    }
}
