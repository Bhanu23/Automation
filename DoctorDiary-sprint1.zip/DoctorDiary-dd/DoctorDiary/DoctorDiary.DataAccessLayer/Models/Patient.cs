﻿using System;
using System.Collections.Generic;

namespace DoctorDiary.DataAccessLayer.Models
{
    public partial class Patient
    {
        public Patient()
        {
            Appointment = new HashSet<Appointment>();
            Detail = new HashSet<Detail>();
            Feedback = new HashSet<Feedback>();
            Prescription = new HashSet<Prescription>();
        }

        public string PatientId { get; set; }
        public string PatientName { get; set; }
        public string EmailId { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }
        public string Contact { get; set; }

        public ICollection<Appointment> Appointment { get; set; }
        public ICollection<Detail> Detail { get; set; }
        public ICollection<Feedback> Feedback { get; set; }
        public ICollection<Prescription> Prescription { get; set; }
    }
}
