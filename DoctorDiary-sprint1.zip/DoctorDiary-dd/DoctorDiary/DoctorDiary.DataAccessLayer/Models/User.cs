﻿using System;
using System.Collections.Generic;

namespace DoctorDiary.DataAccessLayer.Models
{
    public partial class User
    {
        public string EmailId { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
    }
}
