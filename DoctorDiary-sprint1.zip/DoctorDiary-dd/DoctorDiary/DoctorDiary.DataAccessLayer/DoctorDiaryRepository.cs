﻿using DoctorDiary.DataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System.Data.SqlClient;
using System.Collections;

namespace DoctorDiary.DataAccessLayer
{   
    
    public class DoctorDiaryRepository
    {
        DoctorDiaryDBContext context;
        public DoctorDiaryRepository(DoctorDiaryDBContext context)
        {
            this.context = context;
        }
        //Fetch License
        public License GetLicenses(string licenseid)
        {
            License obj = null;
            try
            {
                obj = context.License.Find(licenseid);
                return obj;
            }
            catch (Exception ex)
            {

                obj = null;
            }
            return obj;
        }

        public DoctorDiaryRepository()
        {
            context = new DoctorDiaryDBContext();
        }

        //Fetches the doctor based on specialization.
        public List<Doctor> GetDoctor(string specialization)
        {
            try
            {
                var doctor = (from doc in context.Doctor
                              where doc.SpecializationName == specialization
                              select doc).ToList();
                return doctor;
            }
            catch (Exception)
            {
                return null;
            }
        }

        //Doctor Registration
        public bool RegisterDoctor(Doctor doc)
        {

            bool status = false;
            try
            {
                var abc = @"Exec usp_Insert_Doctor @dn,@g,@e,@dob,@h,@s,@l,@ex";
                context.Database.ExecuteSqlCommand(abc, new SqlParameter("@dn", doc.DoctorName), new SqlParameter("@g", doc.Gender),
                                                   new SqlParameter("@e",doc.EmailId), new SqlParameter("@dob", doc.Dob),
                                                   new SqlParameter("@h",doc.HospitalId), new SqlParameter("@s", doc.SpecializationName),
                                                   new SqlParameter("@l", doc.LicenseId), new SqlParameter("@ex", doc.Experience));
                    
                    context.SaveChanges();
                    status = true;
            }
            catch (Exception ex)
            {
                status = false;
            }
            return status;
        }

        //registration form for Patient.
        public bool RegisterPatient(string patientName, string emailId, string gender, int age, string contact)
        {
            Patient patientObj = new Patient();
            try
            {

                var abc = @"Exec usp_Insert_Patient  @pn,@eid,@gender,@age,@ct";
                context.Database.ExecuteSqlCommand(abc, new SqlParameter("@pn", patientName), new SqlParameter("@eid", emailId),
                    new SqlParameter("@gender", gender), new SqlParameter("@age", age), new SqlParameter("@ct", contact));
                context.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }


        //Shows the detail of doctor to doctor.
        //HospitalName Should be visible to the doctor instead of HospitalId
        public Doctor GetDoctorDetails(string emailId)
        {
            try
            {
                var doctor = (from d in context.Doctor
                              where d.EmailId == emailId
                              select d).FirstOrDefault();
                return doctor;
            }
            catch
            {
                return null;
            }
        }

        //Patient can see thier details using this method.
        public Patient GetPatientDetails(string emailId)
        {
            try
            {
                var patient = (from pat in context.Patient
                               where pat.EmailId == emailId
                               select pat).FirstOrDefault();
                return patient;
            }
            catch (Exception ex)
            {

                return null;
            }
        }


        //doctor can see the list of Appointments for a Today's date.
        public List<Appointment> GetAppointmentDetails(string doctorId)
        {
            try
            {
                var appointment = (from app in context.Appointment
                                   where app.DoctorId == doctorId & app.Date == DateTime.Today
                                   select app).ToList();
                return appointment;
            }
            catch (Exception)
            {

                return null;
            }
        }
        //Ftech Appoints on basis of patienId
        public List<Appointment> GetAppointmentsByPatientId(string patientId)
        {
            List<Appointment> list = new List<Appointment>();
            try
            {
                list = context.Appointment.Where(a => a.PatientId == patientId).ToList();

            }
            catch (Exception)
            {

                list = null;
            }
            return list;
        }
        //Ftech Appoints on basis of doctorId
        public List<Appointment> GetAppointmentsByDoctorId(string doctorId,DateTime date)
        {
            List<Appointment> list = new List<Appointment>();
            try
            {
                list = context.Appointment.Where(a => a.DoctorId == doctorId).Where(a=>a.Date==date).OrderBy(a=>a.AppointmentSlot).ToList();

            }
            catch (Exception ex)
            {

                list = null;
            }
            return list;
        }
        //Fetch slots from Appointment table
        public List<string> GetAppointmentSlotsForDoctor(string doctorId,string date)
        {
            List<string> list = new List<string>();
            try
            {
                DateTime date1 = DateTime.ParseExact(date, "dd/MM/yyyy", null);
                var appoinrmentslots = (from a in context.Appointment where a.DoctorId == doctorId & a.Date == date1 orderby a.AppointmentSlot select a.AppointmentSlot).ToList();
                foreach (var item in appoinrmentslots)
                {
                    string slot = item;
                    list.Add(slot);
                }


            }
            catch (Exception ex)
            {

                list = null;
            }
            return list;
        }

        //Fethecs the list of Available Medicines.
        public List<string> GetMedicinesName()
        {
            try
            {
                List<string> names = new List<string>();
                var medicines = (from med in context.Medicine
                                 select med).ToList();
                foreach (var item in medicines)
                {
                    names.Add(item.MedicineName);
                }
                return names;
            }
            catch
            {
                return null;
            }

        }

        //Fetches the list of All available hospitals.
        public List<string> GetHospitals()
        {
            try
            {
                var hospitals = (from hsp in context.Hospital
                                 select hsp.HospitalName).ToList();
                return hospitals;
            }
            catch (Exception)
            {

                return null;
            }
        }
        //Fetch hospital Name by hospital id
        public string GetHospitalName(string hospitalId)
        {
            string hospitalName = null;
            try
            {
                var hospital = context.Hospital.Find(hospitalId);
                hospitalName = hospital.HospitalName;
            }
            catch (Exception)
            {

                hospitalName = null;
            }
            return hospitalName;
        }
        //shows the feedback for a perticular doctor.
        public List<Feedback> GetFeedback(string doctorId)
        {
            try
            {
                var feedback = (from fb in context.Feedback
                                where fb.DoctorId == doctorId
                                select fb).ToList();
                return feedback;
            }
            catch
            {
                return null;
            }
        }

        //Doctor can see the patient details/history.
        public List<Detail> ViewPatientDetails(string patientId)
        {
            try
            {
                var patient = (from pat in context.Detail
                               where pat.PatientId == patientId
                               select pat).ToList();
                return patient;
            }
            catch (Exception)
            {
                return null;
            }
        }

        //To Add User in the database
        public bool AddUser(string emailId, string password, string role)
        {
            bool status = false;
            User user = new User();

            user.EmailId = emailId;
            user.Password = password;
            user.Role = role;

            try
            {
                context.User.Add(user);
                context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }

            return status;
        }

        //To Update details of doctor
        public bool UpdateDoctorDetail(string doctorId,  string morningSlot, string eveningSlot)
        {
            bool status = false;
            try
            {
                var doc = context.Doctor.Find(doctorId);
                if (doc != null)
                {
                    
                    doc.MorningSlot = morningSlot;
                    doc.EveningSlot = eveningSlot;

                    context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        public bool UpdatePatientDetail(string PatientId, string contact)
        {
            bool status = false;
            try
            {
                var patient = context.Patient.Find(PatientId);
                if (patient != null)
                {

                    patient.Contact = contact;

                    context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        //To Delete appointment , when cancelled by doctor
        public bool DeleteAppointment(string appointmentId)
        {
            bool status = false;
            Appointment appoint = context.Appointment.Find(appointmentId);

            try
            {
                if (appoint != null)
                {
                    context.Appointment.Remove(appoint);
                    context.SaveChanges();
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            catch (Exception)
            {
                status = false;
            }

            return status;
        }

        //details can be added
        public bool AddDetail(string patientId, string doctorId, string remarks, string medicine,string appointmentId ,string referencedDoctorId)
        {
            bool status = false;

            Detail detail = new Detail();
            Doctor doctor = context.Doctor.Find(doctorId);
            Patient patient = context.Patient.Find(patientId);
            try
            {
                if (doctor != null && patient != null)
                {
                    detail.PatientId = patientId;
                    detail.DoctorId = doctorId;
                    detail.Remark = remarks;
                    detail.Reference = referencedDoctorId;
                    detail.Meds = medicine;
                    detail.AppointmentId = appointmentId;
                    context.Detail.Add(detail);
                    context.SaveChanges();
                    status = true;
                }
            }

            catch (Exception)
            {
                status = false;
            }

            return status;
        }

        // doctor can add prescription
        public bool AddPrescription(string patientId, string doctorId, List<string> medicineName, List<string> slot, string appointmentId, byte Validity)
        {

            bool status = false;
            Doctor doctor = context.Doctor.Find(doctorId);
            Patient patient = context.Patient.Find(patientId);
            

            try
            {
                int length1 = medicineName.Count;
                int length2 = medicineName.Count;
                if (doctor != null && patient != null && length1==length2)
                {
                    for (int i = 0; i < length1; i++)
                    {
                        Prescription pres = new Prescription();
                        pres.PatientId = patientId;
                        pres.DoctorId = doctorId;
                        pres.MedicineName = medicineName[i];
                        pres.Slot = slot[i];
                        pres.Date = DateTime.Today;
                        pres.AppointmentId = appointmentId;
                        pres.Validity = Validity;
                        context.Prescription.Add(pres);
                        context.SaveChanges();
                        status = true;
                    }

                }
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        //patient can give feedback
        public bool AddFeedback(string patientId, string doctorId, string feedback, byte? rating)
        {
            bool status = false;
            Doctor doctor = context.Doctor.Find(doctorId);
            Patient patient = context.Patient.Find(patientId);
            Feedback fb = new Feedback();

            try
            {
                if (doctor != null && patient != null)
                {
                    fb.DoctorId = doctorId;
                    fb.PatientId = patientId;
                    fb.Feedback1 = feedback;
                    fb.Rating = rating;
                    context.Feedback.Add(fb);
                    context.SaveChanges();
                    status = true;

                }
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        //patient can get an appointment 
        public bool AddAppointment(string patientId, string doctorId, string appointmentSlot, DateTime date,string Appointmentstatus)
        {
            bool status = false;
            Doctor doctor = context.Doctor.Find(doctorId);
            Patient patient = context.Patient.Find(patientId);
            Appointment app = new Appointment();

            
            try
            {
                if (doctor != null && patient != null)
                {
                    var abc = @"Exec usp_Insert_Appointment @did,@pid,@slot,@date,@status";
                    context.Database.ExecuteSqlCommand(abc, new SqlParameter("@did", doctorId), new SqlParameter("@pid", patientId),
                        new SqlParameter("@slot", appointmentSlot), new SqlParameter("@date", date),new SqlParameter("@status",Appointmentstatus));
                    context.SaveChanges();
                    status= true;
                }               
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        //To get all refered patient
        public List<Detail> GetReference(string doctorId)
        {
            var reference = (from refer in context.Detail
                             where refer.Reference == doctorId
                             select refer).ToList();

            return reference;
        }
        //Fetches Hospital Id
        public string GetHospitalId(string hospitalName)
        {
            string hId = null;
            try
            {
                var obj = context.Hospital.Where(h => h.HospitalName == hospitalName).FirstOrDefault();
                hId = obj.HospitalId;
            }
            catch (Exception ex)
            {

                hId = null;
            }
            return hId;
        }
        //Fetch hospital address and phone by hospital name
        public ArrayList GetHospitalAddressPhone(string hospitalName)
        {
            ArrayList list = new ArrayList();
            try
            {
                var hospital = context.Hospital.Where(h => h.HospitalName == hospitalName).FirstOrDefault();
                if (hospital != null)
                {
                    list.Add(hospital.HospitalAddress);
                    list.Add(hospital.City);
                    list.Add(hospital.Pincode);
                    list.Add(hospital.Contact);
                   
                }
                else
                    list = null;
               
            }
            catch (Exception)
            {

                list = null;
            }
            return list;
        }
        //validate User
        public string ValidateUser(string emailId,string password)
        {
            string role = null;
            try
            {
                var obj = context.User.Find(emailId);
                if (obj != null)
                {
                    if (obj.Password == password)
                    {
                        role = obj.Role;
                    }
                    else
                        role = "Password not found";

                }
                else
                    role = "User not found";
            }
            catch (Exception)
            {

                role = null;
            }
            return role;
        }
        //check email
        public bool CheckEmail(string email,char role)
        {
            bool status = false;
            try
            {
                if (role =='D')
                {
                    var doctor=context.Doctor.Where(d => d.EmailId == email).FirstOrDefault();
                    var user = context.User.Where(u => u.EmailId == email).FirstOrDefault();
                    if (doctor == null && user == null)
                    {
                        status = true;
                    }
                    else
                    {
                        status = false;
                    }
                }
                else
                {
                    var patient = context.Patient.Where(p => p.EmailId == email).FirstOrDefault();
                    var  user = context.User.Where(u => u.EmailId == email).FirstOrDefault();
                    if (patient == null && user == null)
                    {
                        status = true;
                    }
                    else
                        status = false;
                }
            }
            catch (Exception)
            {

                status = false;
            }
            return status;
        }
        //get specialization of doctors
        public List<string> GetSpecialization()
        {
            try
            {
                var lst = (from sn in context.Doctor
                           select sn.SpecializationName).Distinct().ToList();
                return lst;
            }
            catch (Exception)
            {
                return null;
            }
        }
        //get Rating for a doctor
        public decimal? GetRatings(string doctorId)
        {
            try
            {
                var lst = (from rat in context.Feedback
                           where rat.DoctorId == doctorId
                           select rat.Rating).ToList();
                var ratings = lst.Average();
                return ratings;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        //fetches doctor details based on doctor object

        public Doctor GetDoctorById(string doctorId)
        {
            try
            {
                Doctor d = (from doc in context.Doctor
                        where doc.DoctorId == doctorId
                        select doc).FirstOrDefault();
                return d;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        //Fetch doctor slot
        public List<string> GetDoctorSlot(string emailId)
        {
            List<string> list = new List<string>();
            try
            {
                var doctor = context.Doctor.Where(d => d.EmailId == emailId).FirstOrDefault();
                if(doctor.MorningSlot!=null )
                    list.Add(doctor.MorningSlot);
                if(doctor.EveningSlot!=null)
                    list.Add(doctor.EveningSlot);
            }
            catch (Exception)
            {

                list = null;
            }
            return list;
        }
        //Fetch doctor slot by doctorid
        public List<string> GetDoctorSlotBydoctorId(string doctorId)
        {
            List<string> list = new List<string>();
            try
            {
                var doctor = context.Doctor.Find(doctorId);
                list.Add(doctor.MorningSlot);
                list.Add(doctor.EveningSlot);
            }
            catch (Exception)
            {

                list = null;
            }
            return list;
        }
        //fetch patientId by email
        public string GetPatientId(string email)
        {
            string patientId = null;
            try
            {
                var patient = context.Patient.Where(p => p.EmailId == email).FirstOrDefault();
                patientId = patient.PatientId;
            }
            catch (Exception)
            {

                patientId = null;
            }
            return patientId;
        }
        //fetch doctorId by email
        public string GetDoctorId(string email)
        {
            string doctorId = null;
            try
            {
                var doctor = context.Doctor.Where(p => p.EmailId == email).FirstOrDefault();
                doctorId = doctor.DoctorId;
            }
            catch (Exception)
            {

                doctorId = null;
            }
            return doctorId;
        }
        //Fetches Combination of Hospital Address And city and returns a String
        public string Location(string hospitalId)
        {
            try
            {
                var ad = context.Hospital.Find(hospitalId);
                string Location = ad.HospitalAddress +", "+ ad.City;
                return Location;
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        //Update status of Appointment
        public bool UpdateAppointmentStatus(string appointmentId,string appointmentstatus)
        {
            bool status = false;
            try
            {
                var Appointment = context.Appointment.Find(appointmentId);
                Appointment.Status = appointmentstatus;
                context.SaveChanges();
                status = true;

            }
            catch (Exception)
            {

                status = false;
            }
            return status;
        }
        //cancels Appointment
        public bool CancelAppointment(string appointmentId)
        {
            bool status = false;
            try
            {
                var appoointment = context.Appointment.Find(appointmentId);
                context.Appointment.Remove(appoointment);
                context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {

                status = false;
            }
            return status;
        }
        //get doctor name
        public string GetDoctorName(string emailId)
        {
            string name = null;
            try
            {
                var doctor = context.Doctor.Where(d => d.EmailId == emailId).FirstOrDefault();
                name = doctor.DoctorName;
            }
            catch (Exception)
            {

                name = "error";
            }
            return name;
        }
        //get patient name
        public string GetPatientName(string emailId)
        {
            string name = null;
            try
            {
                var patient = context.Patient.Where(d => d.EmailId == emailId).FirstOrDefault();
                name = patient.PatientName;
            }
            catch (Exception)
            {

                name = "error";
            }
            return name;
        }
        //get patient on basis of Patientid
        public Patient GetPatient(string patientId)
        {
            Patient patient = null;
            try
            {
                patient = context.Patient.Find(patientId);
            }
            catch (Exception)
            {

                patient = null;
            }
            return patient;
        }
        //get doctor on basis of doctorId
        public Doctor GetDoctorByDoctorId(string doctorId)
        {
            Doctor doctor = null;
            try
            {
                doctor = context.Doctor.Find(doctorId);
            }
            catch (Exception)
            {

                doctor = null;
            }
            return doctor;
        }
        //Fetch Refrence Doctor List
        public Dictionary<string,string> GetRefrenceDoctorList()
        {
            Dictionary<string, string> dict = new Dictionary<string, string>();
            try
            {
                var Doctors = (from e in context.Doctor select e).ToList();
                foreach (var item in Doctors)
                {

                    dict.Add(item.DoctorId,item.DoctorName);
                    
                }
            }
            catch (Exception)
            {

                dict = null;
            }
            return dict;
        }
        //Ftech Doctors which are refernce to a patient
        public List<Doctor> GetRefrencedDoctorList(string pateintId)
        {
            List<Doctor> doctors = new List<Doctor>();
            try
            {
                List<string> doctorIds = (from de in context.Detail where de.PatientId == pateintId select de.Reference).ToList();
                foreach (var item in doctorIds)
                {
                    
                    if (item != "-N/A-")
                    {
                        var doctor = context.Doctor.Find(item);
                        doctors.Add(doctor);
                    }
                        
                }
            }
            catch (Exception)
            {

                doctors = null;
            }
            return doctors;
        }
        public List<Detail> GetDetailsByPatientId(string  patientId)
        {
            List<Detail> list = new List<Detail>();
            try
            {
                list = (from de in context.Detail where de.PatientId == patientId orderby de.AppointmentId descending select de).ToList();
            }
            catch (Exception)
            {

                list = null;
            }
            return list;
        }
    }
}
