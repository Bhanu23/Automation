﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DoctorDiaryMVC.Models
{
    public class Patient
    {
        public string PatientId { get; set; }
        public string PatientName { get; set; }
        public string EmailId { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }
        public string Contact { get; set; }
    }
}
