﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DoctorDiaryMVC.Models
{
    public class Refrence
    {
        public string DoctorId { get; set; }
        public string DoctorName { get; set; }
    }
}
