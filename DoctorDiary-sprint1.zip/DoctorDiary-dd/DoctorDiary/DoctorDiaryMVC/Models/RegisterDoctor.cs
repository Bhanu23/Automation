﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace DoctorDiaryMVC.Models
{
    public class RegisterDoctor
    {
        [DisplayName("License Id")]
        [RegularExpression("^[L]+([0-9]{6})$", ErrorMessage = "Enter a valid LicenseID")]
        [StringLength(maximumLength: 7, MinimumLength = 7)]
        [Required(ErrorMessage = "LicenseId is required.")]
        public string LicenseId { get; set; }

        [RegularExpression("^[a-z0-9_\\+-]+(\\.[a-z0-9_\\+-]+)*@[a-z0-9-]+(\\.[a-z0-9]+)*\\.([a-z]{2,4})$", ErrorMessage = "Enter a valid EmailId")]
        [Required(ErrorMessage = "EmailId is required.")]
        [DisplayName("Email Id")]
        public string EmailId { get; set; }

        [RegularExpression("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,15}$", ErrorMessage = "Must contain atleast one number, one uppercase and lowercase letter, and atleast 8 or more characters")]
        //[StringLength(maximumLength: 15,MinimumLength =8, ErrorMessage = "Password range should be btw 8 and 15")]
        [Required(ErrorMessage = "Password is required.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        //[StringLength(maximumLength: 15,MinimumLength =8, ErrorMessage = "Password range should be btw 8 and 15")]
        [Required(ErrorMessage = "Confirm Password is required.")]
        [DisplayName("Confirm Password")]
        [DataType(DataType.Password, ErrorMessage = "Password donot match")]
        [Compare("Password")]
        public string Con_Password { get; set; }

        [DisplayName("Hospital Name")]
        public string HospitalName { get; set; }
    }
}
