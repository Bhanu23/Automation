﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DoctorDiaryMVC.Models
{
    public class Login
    {   
        [Required(ErrorMessage ="Email is required")]
        [RegularExpression(@"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$", ErrorMessage = "Invalid email address.")]
        [DisplayName("Email Id")]
        public string EmailId { get; set; }

        //[Required(ErrorMessage = "Password is required")]
        //[DisplayName("Password")]
        //public string Password { get; set; }

        //[Required(ErrorMessage = "Email is required")]
        //[RegularExpression(@"^[a-z0-9_\\+-]+(\\.[a-z0-9_\\+-]+)*@[a-z0-9-]+(\\.[a-z0-9]+)*\\.([a-z]{2,4})$", ErrorMessage = "Invalid email address.")]
        //[DisplayName("Email Id")]
        //public string EmailId { get; set; }

        [RegularExpression("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,15}$", ErrorMessage = "Must contain atleast one number, one uppercase and lowercase letter, and atleast 8 or more characters")]
        [Required(ErrorMessage = "Password is required")]
        [DisplayName("Password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }


    }
}
