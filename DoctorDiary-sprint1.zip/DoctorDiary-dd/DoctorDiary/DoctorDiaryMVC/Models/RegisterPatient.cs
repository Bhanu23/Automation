﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DoctorDiaryMVC.Models
{
    public class RegisterPatient
    {
        [RegularExpression("^[a-zA-Z][a-zA-Z ]+[a-zA-Z]$", ErrorMessage = "Name must only include alphabets")]
        [Required(ErrorMessage = "Name is required.")]
        [DisplayName("Name")]
        public string Name { get; set; }

        [RegularExpression("^[a-z0-9_\\+-]+(\\.[a-z0-9_\\+-]+)*@[a-z0-9-]+(\\.[a-z0-9]+)*\\.([a-z]{2,4})$", ErrorMessage = "Enter a valid EmailId")]
        [Required(ErrorMessage = "EmailId is required.")]
        [DisplayName("Email Id")]
        //[Remote("IsAlreadySigned", "Home", HttpMethod = "POST", ErrorMessage = "EmailId already exists in database.")]
        public string EmailId { get; set; }

        [RegularExpression("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,15}$", ErrorMessage = "Must contain atleast one number, one uppercase and lowercase letter, and atleast 8 or more characters")]
        [Required(ErrorMessage = "Password is required.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required(ErrorMessage = "Confirm Password is required.")]
        [DisplayName("Confirm Password")]
        [DataType(DataType.Password, ErrorMessage = "Password donot match")]
        [Compare("Password")]
        public string ConfirmPassword { get; set; }

        [Required(ErrorMessage = "DOB is required.")]
        [DataType(DataType.Date)]
        public DateTime DOB { get; set; }

        [Required(ErrorMessage = "Gender is required.")]
        public string Gender { get; set; }

        [StringLength(10, MinimumLength = 10, ErrorMessage = "Incorrect mobile number")]
        [RegularExpression("([6-9][0-9]*)", ErrorMessage = "Incorrect number format")]
        [Required(ErrorMessage = "Mobile Number is required.")]
        public string PhoneNumber { get; set; }


    }
}