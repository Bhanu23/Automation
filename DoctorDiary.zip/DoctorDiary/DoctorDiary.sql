--USE Master;
--GO
--Drop database DoctorDiaryDB
--GO

create database DoctorDiaryDB
GO
USE DoctorDiaryDB

---Table Drop---
IF OBJECT_ID('[User]')  IS NOT NULL
DROP TABLE [User]
GO
IF OBJECT_ID('Hospital')  IS NOT NULL
DROP TABLE Hospital
GO
IF OBJECT_ID('Prescription')  IS NOT NULL
DROP TABLE Prescription
GO
IF OBJECT_ID('Appointment')  IS NOT NULL
DROP TABLE Appointment
GO
IF OBJECT_ID('Feedback')  IS NOT NULL
DROP TABLE Feedback
GO
IF OBJECT_ID('Detail')  IS NOT NULL
DROP TABLE Detail
GO
IF OBJECT_ID('Patient')  IS NOT NULL
DROP TABLE Patient
GO
IF OBJECT_ID('Medicine')  IS NOT NULL
DROP TABLE Medicine
GO
IF OBJECT_ID('Doctor')  IS NOT NULL
DROP TABLE Doctor
GO
IF OBJECT_ID('License')  IS NOT NULL
DROP TABLE License
GO

---Procedure Drop---
IF OBJECT_ID('usp_Insert_User')  IS NOT NULL
DROP PROC usp_Insert_User
GO
IF OBJECT_ID('usp_Insert_License')  IS NOT NULL
DROP PROC usp_Insert_License
GO
IF OBJECT_ID('usp_Insert_Doctor')  IS NOT NULL
DROP PROC usp_Insert_Doctor
GO
IF OBJECT_ID('usp_Insert_Hospital')  IS NOT NULL
DROP PROC usp_Insert_Hospital
GO
IF OBJECT_ID('usp_Insert_Medicine')  IS NOT NULL
DROP PROC usp_Insert_Medicine
GO
IF OBJECT_ID('usp_Insert_Prescription')  IS NOT NULL
DROP PROC usp_Insert_Prescription
GO
IF OBJECT_ID('usp_Insert_Patient')  IS NOT NULL
DROP PROC usp_Insert_Patient
GO
IF OBJECT_ID('usp_Insert_Appointment')  IS NOT NULL
DROP PROC usp_Insert_Appointment
GO
IF OBJECT_ID('usp_Insert_Feedback')  IS NOT NULL
DROP PROC usp_Insert_Feedback
GO
IF OBJECT_ID('usp_Insert_Detail')  IS NOT NULL
DROP PROC usp_Insert_Detail
GO

---Sequence Drop---
IF OBJECT_ID('Sequence_Doctor')  IS NOT NULL
DROP SEQUENCE Sequence_Doctor
GO
IF OBJECT_ID('Sequence_Patient')  IS NOT NULL
DROP SEQUENCE Sequence_Patient
GO
IF OBJECT_ID('Sequence_Appointment')  IS NOT NULL
DROP SEQUENCE Sequence_Appointment
GO
IF OBJECT_ID('Sequence_License')  IS NOT NULL
DROP SEQUENCE Sequence_License
GO
IF OBJECT_ID('Sequence_Hospital')  IS NOT NULL
DROP SEQUENCE Sequence_Hospital
GO
IF OBJECT_ID('Sequence_Medicine')  IS NOT NULL
DROP SEQUENCE Sequence_Medicine
GO

--DROP SEQUENCE seqname ;  
--GO 

Create Sequence Sequence_Doctor
Start with 1000
Increment by 1
MaxValue 9999;
go

Create Sequence Sequence_Patient
Start with 100000
Increment by 1
MaxValue 999999;
go

Create Sequence Sequence_Appointment
Start with 100000
Increment by 1
MaxValue 999999;
go

Create Sequence Sequence_License
Start with 100000
Increment by 1
MaxValue 999999;
go

Create Sequence Sequence_Hospital
Start with 1000
Increment by 1
MaxValue 2000;
go

Create Sequence Sequence_Medicine
Start with 1000
Increment by 1
MaxValue 9999;
go


create table [User]
(
EmailId varchar(50) Not null,
[Password] varchar(20) not null,
[Role] char(1) not null
Constraint PK_User Primary Key (EmailId)
)

go
create table License
(
LicenseId char(7) not null,
DoctorName Varchar(20) not null,
Degree Varchar(10) not null,
Gender char(1) not null,
SpecializationName varchar(50) not null,
Dob Date not null,
LID date not null 
Constraint PK_License Primary Key (LicenseId)
)

go
create table Doctor
(
DoctorId char(5) not null,
DoctorName Varchar(20) not null,
Gender Char(1) not null,
EmailId varchar(50) not null,
Dob Date not null,
HospitalId char(5) not null,
SpecializationName varchar(50) not null,
MorningSlot varchar(15),
EveningSlot varchar(15),
LicenseId char(7) not null,
Constraint PK_Doctor Primary Key (DoctorId),
Constraint FK_Doctor Foreign Key (LicenseId) References License (LicenseId)
)
go
alter table Doctor
add Experience int

go
Create Table Patient
(
PatientId char(7) not null,
PatientName varchar(20) not null,
EmailId varchar(50) not null,
Gender char(1) Not null,
Age int not null,
Contact varchar(15) not null,
Constraint PK_Patient Primary Key (PatientId),
Constraint UN_Patient Unique (EmailId)
)

go
Create Table Hospital
(
HospitalId char(5) not null,
HospitalName varchar(70) not null,
HospitalAddress Varchar(100) not null,
City Varchar(20) not null,
Pincode numeric(6) not null,
Contact varchar(15) not null,
Constraint PK_Hospital Primary Key (HospitalId)
)

go
Create Table Medicine
(
MedicineId char(7) not null,
MedicineName Varchar(30) not null,
Constraint PK_Medicine Primary Key (MedicineId)
)

go
Create Table Prescription
(
PatientId Char(7) not null,
DoctorId Char(5) not null,
MedicineName Varchar(30) not null,
Slot char(3) not null,
Quantity float not null,
Constraint PK_Prescription Primary Key (PatientId,DoctorId,MedicineName),
Constraint FK_Prescription1 Foreign Key (PatientId) References Patient (PatientId),
Constraint FK_Prescription2 Foreign Key (DoctorId) References Doctor (DoctorId)
)
go
alter table Prescription
add [Date] date not null

go
Create Table Appointment
(
AppointmentId char(7) not null,
DoctorId char(5) not null,
PatientId char(7) not null,
AppointmentSlot char(3) not null
Constraint PK_Appointment Primary Key (AppointmentId),
Constraint FK_Appointment1 Foreign Key (PatientId) References Patient (PatientId),
Constraint FK_Appointment2 Foreign Key (DoctorId) References Doctor (DoctorId)
)
go
alter table Appointment
add [Date] date not null

go
Create Table Feedback
(
DoctorId char(5) not null,
PatientId char(7) not null,
Feedback varchar(100),
Rating decimal,
Constraint PK_Feedback Primary Key (DoctorId,PatientId),
Constraint FK_Feedback1 Foreign Key (PatientId) References Patient (PatientId),
Constraint FK_Feedback2 Foreign Key (DoctorId) References Doctor (DoctorId)
)

go
Create Table Detail
(
PatientId char(7) not null,
DoctorId char(5) not null,
Remark varchar(100) not null,
Meds varchar(70) not null,
Reference char(5),
Constraint PK_Detail Primary Key (DoctorId,PatientId),
Constraint FK_Detail1 Foreign Key (PatientId) References Patient (PatientId),
Constraint FK_Detail2 Foreign Key (DoctorId) References Doctor (DoctorId)
)

go
create Procedure usp_Insert_User (@emaiId varchar(50), @password varchar(20), @role char(1))
as
begin

	Insert into [User](EmailId, [Password], [Role])
	            values (@emaiId, @password, @role)

end

go
create Procedure usp_Insert_License (@doctorName varchar(20), @degree varchar (10), @gender char(1),
                                     @specializationName varchar(50), @dob date, @lid date)
as
begin
	declare @licenseId char(7),
		    @nextValue int = Next value For Sequence_License

	select @licenseId = 'L' + convert (char(6),@nextValue) 

	Insert into License(LicenseId, DoctorName, Degree, Gender, SpecializationName, Dob, LID)
	            values (@licenseId, @doctorName, @degree, @gender, @specializationName, @dob, @lid)

end

go

Create Procedure [dbo].[usp_Insert_Doctor] (@doctorName varchar(20), @gender char(1), @emailId varchar(50),
                                    @dob date, @hospitalId char(5), @specailizationName varchar(50), 
									@licenseId char(7), @experience int)
as
begin
Declare 
		@doctorId char(5),
		@nextValue int = Next value For Sequence_Doctor

	select @doctorId = 'D' + convert (char(4),@nextValue) 

	Insert into Doctor(DoctorId, DoctorName, Gender, EmailId, Dob, HospitalId, SpecializationName, LicenseId, Experience) 
	            values(@doctorId, @doctorName, @gender, @emailId, @dob, @hospitalId, @specailizationName,
	                           @licenseId, @experience)
end


go
create Procedure usp_Insert_Hospital (@hospitalName varchar(70), @hospitalAddress varchar(100), @city varchar(20),
                                      @pincode Numeric(6),@contact varchar(15))
as
begin
declare @hospitalId char(5),
        @nextValue int = Next Value For Sequence_Hospital

	select @hospitalId = 'H' + convert (char(4),@nextValue)

	Insert into Hospital(HospitalId, HospitalName, HospitalAddress, City, Pincode, Contact)
	            values (@hospitalId, @hospitalName, @hospitalAddress, @city, @pincode, @contact)

end

go
create Procedure usp_Insert_Medicine (@medicineName varchar(30))
as
begin
declare @medicineId char(5),
        @nextValue int = Next Value For Sequence_Medicine

	select @medicineId = 'M' + convert (char(4),@nextValue)

	Insert into Medicine(MedicineId, MedicineName)
	            values (@medicineId, @medicineName)

end

go
create Procedure usp_Insert_Prescription (@patientId char(7), @doctorId char(5),@medicineName varchar(30), 
                                          @slot char(3), @quantity float )
as
begin

	Insert into Prescription(PatientId, DoctorId, MedicineName, Slot, Quantity)
	            values (@patientId,@doctorId, @medicineName, @slot, @quantity)

end

go
create Procedure usp_Insert_Patient (@patientName varchar(20), @emailId varchar(50), @gender char(1), @age int,
                                      @contact varchar(15))
as
begin
declare @patientId char(7),
        @nextValue int = Next Value For Sequence_Patient

	select @patientId = 'P' + convert (char(6),@nextValue)

	Insert into Patient(PatientId, PatientName, EmailId, Gender, Age, Contact)
	            values (@patientId, @patientName, @emailId, @gender, @age, @contact)

end

go
create Procedure usp_Insert_Appointment (@doctorId char(5), @patientId char(7), @appointmentSlot char(3))
as
begin
declare @appointmentId char(7),
        @nextValue int = Next Value For Sequence_Appointment

	select @appointmentId = 'A' + convert (char(6),@nextValue)

	Insert into Appointment(AppointmentId, DoctorId, PatientId, AppointmentSlot)
	            values (@appointmentId, @doctorId, @patientId, @appointmentSlot)

end

go
create Procedure usp_Insert_Feedback (@doctorId char(5), @patientId char(7), 
                                      @feedback varchar(100), @rating decimal)
as
begin

	Insert into Feedback(DoctorId, PatientId, Feedback,	Rating)
	            values (@doctorId, @patientId, @feedback, @rating)

end

go
create Procedure usp_Insert_Detail (@patientId char(7), @doctorId char(5), @remark varchar(100), 
                                    @meds varchar(70), @reference char(5))
as
begin

	Insert into Detail(PatientId, DoctorId, Remark, Meds, Reference)
	            values (@patientId, @doctorId, @remark, @meds, @reference)

end

go
exec usp_Insert_User 'User1example.gmail.com', '1234567', 'P'

go
exec usp_Insert_License 'Deepak Malhotra', 'M.D.', 'M', 'Neuro Surgeon', '1985-12-10', '2014-03-24'
exec usp_Insert_License 'Aadi Ghosh', 'PhD', 'F', 'Gynecologist', '1986-04-07', '2013-02-10'
exec usp_Insert_License 'Aadidev Kohli', 'MM', 'M', 'Pathologist', '1987-05-11', '2012-01-07'
exec usp_Insert_License 'Aadinath Patel', 'DCM', 'M', 'Gynecologist', '1984-09-24', '2014-09-03'
exec usp_Insert_License 'Aaditya Joshi', 'M.D.', 'M', 'Pathologist', '1987-04-13', '2013-07-05'
exec usp_Insert_License 'Aahish Iyer', 'MMSc', 'M', 'Pediatrician', '1982-12-11', '2012-05-07'
exec usp_Insert_License 'Akshita Goswami', 'MM', 'F', 'Neuro Surgeon', '1982-05-13', '2014-03-09'
exec usp_Insert_License 'Alok Agarwal', 'PhD', 'M', 'Psychiatrist', '1985-04-11', '2014-01-24'
exec usp_Insert_License 'Aamir Malhotra', 'M.D.', 'M', 'Neuro Surgeon', '1985-12-24', '2013-12-11'
exec usp_Insert_License 'Aarav Kohli', 'PhD', 'M', 'Dermatologist ', '1987-07-13', '2013-10-13'
exec usp_Insert_License 'Daanesh Arya', 'M.D.', 'M', 'Neuro Surgeon', '1983-04-11', '2015-08-15'
exec usp_Insert_License 'Dael Reddy', 'DS', 'M', 'Ophthalmologist', '1983-05-28', '2015-06-17'
exec usp_Insert_License 'Divya Patel', 'M.D.', 'F', 'Neuro Surgeon', '1981-12-10', '2011-04-19'
exec usp_Insert_License 'Dakshit Bhatt', 'MMSc', 'M', 'Urologist', '1985-04-05', '2011-02-21'
exec usp_Insert_License 'Dalla Singh', 'DCM', 'M', 'Pediatrician', '1984-11-28', '2010-03-24'
exec usp_Insert_License 'Harsh Agarwal', 'DS', 'M', 'Psychiatrist', '1986-06-07', '2014-05-23'
exec usp_Insert_License 'Habel Grover', 'M.D.', 'M', 'Pathologist', '1982-12-19', '2010-07-22'
exec usp_Insert_License 'Haden Haldar', 'DS', 'M', 'Neuro Surgeon', '1983-05-11', '2014-04-25'
exec usp_Insert_License 'Hafeez Khan', 'DCM', 'M', 'Gynecologist', '1984-06-19', '2013-06-11'
exec usp_Insert_License 'Hakim', 'M.D.', 'MM', 'Neuro Surgeon', '1985-08-05', '2012-03-01'
exec usp_Insert_License 'Harpreet Dalal', 'PhD', 'F', 'Cardiologist', '1982-05-13', '2012-05-28'
exec usp_Insert_License 'Lora Sea','DM','F','General Surgeon','1983-2-12','2010-06-14'
exec usp_Insert_License 'Vicente Doby','MS','M','Cardiothoracic Surgeon','1989-08-12','2016-12-25'
exec usp_Insert_License 'Stephania Jester','DS','F','NeuroSurgeon','1980-06-16','2014-07-31'
exec usp_Insert_License 'Jayna Terrel','MSc','F','maxillofacial Surgeon','1982-02-24','2016-11-26'
exec usp_Insert_License 'Alonso Haven','DS','M','General Surgeon','1987-03-12','2010-03-15'
exec usp_Insert_License 'Eli Horstman','MS','M','Cardiothoracic Surgeon','1977-02-03','2010-04-30'
exec usp_Insert_License 'Imelda Geisel','Mbbs','F','Ophthalmic Surgeon','1977-09-22','2010-09-21'
exec usp_Insert_License 'Ellan Wolfgang','MS','M','Plastic Surgeon','1978-01-05','2010-10-07'
exec usp_Insert_License 'Joan Wagener','MS','M','Trauma Surgeon','1978-09-09','2011-11-14'
exec usp_Insert_License 'Charise Burtner','DS','F','Vascular Surgeon','1979-10-26','2012-05-03'
exec usp_Insert_License 'Larry Michaelsen','MBBS','F','Bariatric Surgeon','1980-05-11','2013-04-03'
exec usp_Insert_License 'Rozella Michalik','MS','F','Transplant Surgeon','1980-11-17','2014-06-16'
exec usp_Insert_License 'Val Stonerock','DS','M','Endocrine Surgeon','1981-05-24','2015-01-05'
exec usp_Insert_License 'Elodia Girton','BDS','F','Dentist','1981-09-09','2016-07-07'
exec usp_Insert_License 'Suanne Knapper','BAMS','M','Physician','1982-04-26','2016-11-03'
exec usp_Insert_License 'Noriko Williamson','BDS','M','Dentist','1982-06-13','2016-12-20'
exec usp_Insert_License 'Charlott Sieren','MBBS','F','Physician','1982-08-20','2016-12-31'
exec usp_Insert_License 'Kristin Wronski','BAMS','M','Physician','1983-06-06','2017-08-26'
exec usp_Insert_License 'Warren Vero','MBBS','M','Physician','1984-02-20','2018-08-11'
exec usp_Insert_License 'Deepanshu Goswami', 'M.D.', 'M', 'Neuro Surgeon', '1986-09-11', '2014-03-24'
exec usp_Insert_License 'Karan Sharma',' M.B.B.S.','M','Orthopaedic Surgery','1988-04-18','2018-03-07'
exec usp_Insert_License 'Khushboo Sharma','M.B.B.S, M.D','F','Gynecologist','1986-10-11','2015-10-21'
exec usp_Insert_License 'shivam Sharma','M.S,M.D','M','Neurologist','1985-12-21','2016-09-26'
exec usp_Insert_License 'Krishna Yadav','M.B.B..S','M','Ophthalmic Surgeon','1980-04-15','2010-05-06'
exec usp_Insert_License 'Tanya Gupta','M.B.B.S','F','Spine Surgeon','1979-02-11','2008-04-07'
exec usp_Insert_License 'Priyanka Chouhan','M.B.B.S','F','Plastic and Maxillofacial Surgeon','1974-06-04','2002-05-08'
exec usp_Insert_License 'Ishita Solanki','M.D','F','Pediatric Oncologist','1977-08-03','2007-06-11'
exec usp_Insert_License 'Shreya Goyal','M.B.B.S','F','Cardiologist','1983-03-22','2012-05-23'
exec usp_Insert_License 'Anjali Sharma','M.B.B.S','F','Dermatologist','1982-04-27','2010-11-24'
exec usp_Insert_License 'Rohan Sharma','B.H.M.S','M','Ophthalmologist','1980-12-27','2010-03-22'
exec usp_Insert_License 'Kunal Sharma','M.B.B.S','M','Physician','1975-08-13','2001-12-22'
exec usp_Insert_License 'Gayatri Sharma','M.B.B.S','F','Physician','1989-02-07','2018-12-26'		
exec usp_Insert_License 'Nishant Mishra','M.B.B.S','M','Physician','1979-10-05','2009-07-20'
exec usp_Insert_License 'Sakshi Gupta','M.D','F','Neurologist','1982-05-11','2011-02-12'
exec usp_Insert_License 'Aswini Roy','M.B.B.S','M','Pulmonologist','1974-06-23','2003-05-16'
exec usp_Insert_License 'Aryan Khanna','M.B.B.S','M','Nephrologist','1985-12-24','2017-11-29'
exec usp_Insert_License 'Mayank Singh','M.B.B.S','M','Pulmonologist','1979-06-22','2007-12-08'
exec usp_Insert_License 'Pranav Shrivastava','M.B.B.S','M','Nephrologist','1983-04-11','2012-08-12'
exec usp_Insert_License 'Vaibhav Kapoor','M.D','M','Neurologist','1977-06-06','2006-10-15'

go
exec usp_Insert_Medicine 'ACARBOSE-50mg'
exec usp_Insert_Medicine 'ACETAZOLAMIDE-1000mg'
exec usp_Insert_Medicine 'ACYCLOVIR-200mg'
exec usp_Insert_Medicine 'ALBENDAZOLE-400mg'
exec usp_Insert_Medicine 'AMANTADINE-200mg'
exec usp_Insert_Medicine 'AMOXYCILLIN-500mg'
exec usp_Insert_Medicine 'AMPICILLIN-1000mg'
exec usp_Insert_Medicine 'AMYLASE-10mg'
exec usp_Insert_Medicine 'BISOPROLOL-20mg'
exec usp_Insert_Medicine 'CARBAMAZEPINE-1600mg'
exec usp_Insert_Medicine 'DIPYRIDAMOLE-600mg'
exec usp_Insert_Medicine 'OLANZAPINE-10mg'
exec usp_Insert_Medicine 'PIROXICAM-30mg'
exec usp_Insert_Medicine 'PRAVASTATIN-40mg'
exec usp_Insert_Medicine 'ASPIRIN-50mg'
exec usp_Insert_Medicine 'ATROPINE-2mg'
exec usp_Insert_Medicine 'BACLOFEN-15mg'
exec usp_Insert_Medicine 'BETAHISTINE-16mg'
exec usp_Insert_Medicine 'BUPIVACAINE HCL-150mg'
exec usp_Insert_Medicine 'CALCIPOTRIOL-15mg'
exec usp_Insert_Medicine 'CARBOPLATIN-360mg'
exec usp_Insert_Medicine 'CARVEDILOL-25mg'
exec usp_Insert_Medicine 'CEFIXIME-400mg'
exec usp_Insert_Medicine 'CEFTIZOXIME-10mg'
exec usp_Insert_Medicine 'CETIRIZINE-10mg'
exec usp_Insert_Medicine 'CLINDAMYCIN-300mg'
exec usp_Insert_Medicine 'CLOXACILLIN-500mg'
exec usp_Insert_Medicine 'DICYCLOMINE-20mg'
exec usp_Insert_Medicine 'DINOPROSTONE-15mg'
exec usp_Insert_Medicine 'DIOSMIN-300mg'
exec usp_Insert_Medicine 'DISOPYRAMIDE-150mg'
exec usp_Insert_Medicine 'DOXAZOSIN-10mg'
exec usp_Insert_Medicine 'DOXEPIN-100mg'
exec usp_Insert_Medicine 'ERYTHROMYCIN-250mg'
exec usp_Insert_Medicine 'FLAVOXATE-200mg'
exec usp_Insert_Medicine 'FLUCONAZOL-500mg'
exec usp_Insert_Medicine 'GLICLAZIDE-80mg'
exec usp_Insert_Medicine 'INDAPAMIDE-2.5mg'
exec usp_Insert_Medicine 'KETAMINE-5mg'
exec usp_Insert_Medicine 'LORATADINE-5-10mg'
exec usp_Insert_Medicine 'MIDAZOLAM-20mg'
exec usp_Insert_Medicine 'NALOXONE-10mg'
exec usp_Insert_Medicine 'NIMESULIDE-100mg'
exec usp_Insert_Medicine 'NYSTATIN-100ml'
exec usp_Insert_Medicine 'OFLOXACIN-400mg'
exec usp_Insert_Medicine 'ORNIDAZOLE-500mg'
exec usp_Insert_Medicine 'OXAZEPAM-30mg'
exec usp_Insert_Medicine 'PANCREATIN-600mg'
exec usp_Insert_Medicine 'PINDOLOL-40mg'
exec usp_Insert_Medicine 'PIRIBEDIL-10mg'
exec usp_Insert_Medicine 'PRAZOSIN-15mg'
exec usp_Insert_Medicine 'PRIMIDONE-20mg'
exec usp_Insert_Medicine 'RAMPIRIL-1.25mg'
exec usp_Insert_Medicine 'RUTIN-40mg'
exec usp_Insert_Medicine 'RIBAVIRIN-200mg'
exec usp_Insert_Medicine 'SISOMICIN-3mg'
exec usp_Insert_Medicine 'SOFRAMYCIN-1mg'
exec usp_Insert_Medicine 'SPIRULINA-40mg'
exec usp_Insert_Medicine 'SUCRALAFATE-1gm'
exec usp_Insert_Medicine 'SUMATRIPTAN-40mg'
exec usp_Insert_Medicine 'TAMOXIFEN-20mg'
exec usp_Insert_Medicine 'TERAZOSIN-20mg'
exec usp_Insert_Medicine 'TETRACYCLINE-2gm'
exec usp_Insert_Medicine 'TIMOLOL-2ml'
exec usp_Insert_Medicine 'TOLNAFTATE-40mg'
exec usp_Insert_Medicine 'TRICLOFOS-150mg'
exec usp_Insert_Medicine 'UROKINASE-80mg'
exec usp_Insert_Medicine 'VALETHAMATE-8mg'
exec usp_Insert_Medicine 'VERAPAMIL-480mg'
exec usp_Insert_Medicine 'WARFARIN-15mg'
exec usp_Insert_Medicine 'XIPAMIDE-40mg'
exec usp_Insert_Medicine 'ZOPICLONE-15mg'

go
exec usp_Insert_Hospital 'All India Institute of Medical Sciences','Ansari Nagar','Delhi',110023,'011-2374563'
exec usp_Insert_Hospital 'Artemis Hospital','Sector-51','Gurgaon',122001,'011-3478125'
exec usp_Insert_Hospital 'Columbia Asia','Sector-23','Gurgaon',122017,'011-8456237'
exec usp_Insert_Hospital 'Cloudnine Hospitals','Mayfield Gardens Sector 47','Gurgaon',122018,'011-6598236'
exec usp_Insert_Hospital 'Dr. Mohan’s Diabetes Specialities Centre','sector-18','Noida',201301,'011-8127345'
exec usp_Insert_Hospital 'Dharamshila Cancer Hospital and Research Centre','Dharamshila Marg,Vasundhara Enclave,Near New Ashok Nagar Metro Station','Delhi',110096,'011-5467436'
exec usp_Insert_Hospital 'Eden Hospital','East of Kailash','New-Delhi',700021,'011-3451282'
exec usp_Insert_Hospital 'Fortis Hospital','Sector-44','Gurgaon',122001,'011-7612315'
exec usp_Insert_Hospital 'Guru Teg Bahadur Hospital','Dilshad Garden','Delhi',110095,'011-6737173'
exec usp_Insert_Hospital 'Holy Family Hospital','Jamia Nagar, Friends Colony','Delhi',110025,'011-1245692'
exec usp_Insert_Hospital 'Indraprastha Apollo Hospital','Sarita Vihar','Delhi',110076,'011-7834242'
exec usp_Insert_Hospital 'Kasturba Hospital','Daryaganj','Delhi',110002,'011-9856727'
exec usp_Insert_Hospital 'Lady Hardinge Medical College',' Shaheed Bhagat Singh Marg','Delhi',110001,'011-8235177'
exec usp_Insert_Hospital 'Maharaja Agrasen Hospital','West Punjabi Bagh','New-Delhi',110026,'011-8234111'
exec usp_Insert_Hospital 'Maulana Azad Medical College','Bahadur Shah Zafar Marg','New-Delhi',110002,'011-4823193'
exec usp_Insert_Hospital 'Max Healthcare','Sector-56','Noida',201301,'011-6281375'
exec usp_Insert_Hospital 'Medanta The Medicity','Railwary Road','Gurgaon',122006,'011-7129357'
exec usp_Insert_Hospital 'National Heart Institute','Community Centre, East of Kailash','New-Delhi',110065,'011-5167222'
exec usp_Insert_Hospital 'Ram Manohar Lohia Hospital','Baba Kharag Singh Marg','Delhi',110001,'011-7892345'
exec usp_Insert_Hospital 'Rajiv Gandhi Cancer Institute and Research Centre',' Rohini','New-Delhi',110085,'011-2673182'
exec usp_Insert_Hospital 'Sanjeevan Hospitals','24, Ansari Road Darya Ganj','New-Delhi',110055,'011-4723911'
exec usp_Insert_Hospital 'Sir Ganga Ram Hospital','Rajendar Nagar','New-Delhi',110060,'011-6723561'
exec usp_Insert_Hospital 'Sunrise Hospital & Medical Center','Sector 15 Rohini','Delhi',110085,'011-4728351'
go


exec usp_Insert_Feedback 'D1050','P100000','feedback from 1','8'
exec usp_Insert_Feedback 'D1050','P100001','feedback from 2','3'
exec usp_Insert_Feedback 'D1050','P100002','feedback from 3','5'
exec usp_Insert_Feedback 'D1050','P100003','feedback from 4','10'
exec usp_Insert_Feedback 'D1050','P100004','feedback from 5','8'
exec usp_Insert_Feedback 'D1051','P100001','feedback from 2','7'
exec usp_Insert_Feedback 'D1051','P100003','feedback from 4','5'
exec usp_Insert_Feedback 'D1051','P100004','feedback from 5','8'
exec usp_Insert_Feedback 'D1052','P100000','feedback from 1','5'
exec usp_Insert_Feedback 'D1052','P100006','feedback from 7','7'
exec usp_Insert_Feedback 'D1052','P100002','feedback from 3','9'
exec usp_Insert_Feedback 'D1052','P100007','feedback from 8','10'
exec usp_Insert_Feedback 'D1053','P100004','feedback from 5','6'
exec usp_Insert_Feedback 'D1053','P100006','feedback from 7','4'
exec usp_Insert_Feedback 'D1053','P100001','feedback from 2','9'
exec usp_Insert_Feedback 'D1053','P100008','feedback from 9','8'
exec usp_Insert_Feedback 'D1055','P100005','feedback from 6','7'
exec usp_Insert_Feedback 'D1055','P100007','feedback from 8','8'
exec usp_Insert_Feedback 'D1055','P100000','feedback from 1','9'
exec usp_Insert_Feedback 'D1055','P100001','feedback from 2','6'
exec usp_Insert_Feedback 'D1056','P100005','feedback from 6','9'
exec usp_Insert_Feedback 'D1056','P100006','feedback from 7','8'
exec usp_Insert_Feedback 'D1056','P100009','feedback from 10','8'
go

exec usp_Insert_Patient 'Rahul Singh','rahul.singh@gmail.com','M',22,'9876543210'
exec usp_Insert_Patient 'Deepak Kumar','deepak.Kumar@yahoo.com','M',20,'8320782485'
exec usp_Insert_Patient 'Shivani Singh','shivani.singh@gmail.com','F',16,'9311185523'
exec usp_Insert_Patient 'Adarsh Kumar','adarsh.Kumar@yahoo.com','M',22,'70111252'
exec usp_Insert_Patient 'satyam Singh','satyam.singh@gmail.com','M',18,'7860378255'
exec usp_Insert_Patient 'Mayur Singh','mayur.singh@gmail.com','M',22,'9425825175'
exec usp_Insert_Patient 'Pranav Khandelwaal','pranav.khandelwaal@yahoo.com','M',16,'7300583761'
exec usp_Insert_Patient 'Shashank Singh','shashank.singh@gmail.com','F',16,'9540449449'
exec usp_Insert_Patient 'Nitin Raj','nitin.raj@gmail.com','M',19,'7359420407'
exec usp_Insert_Patient 'Mohan Singh','mohan.singh@yahoo.com','M',18,'9780404043'
exec usp_Insert_Patient 'Arya Stark','arya.stark@gmail.com','F',12,'9417279576'
exec usp_Insert_Patient 'Tony Stark','tony.stark@gmail.com','M',13,'9003556672'
exec usp_Insert_Patient 'Raju Rastogi','raju.rastogi@yahoo.com','M',10,'9995239993'
exec usp_Insert_Patient 'Chetan Bakshi','chetan.bakshi@gmail.com','M',18,'7980197958'
exec usp_Insert_Patient 'Muskan Chugh','muskan.chugh@gmail.com','F',8,'9451469411'
exec usp_Insert_Patient 'Soumya Raj','soumya.raj@gmail.com','F',18,'9140273280'
exec usp_Insert_Patient 'Nimisha Chaudhary','nimisha.chaudhary@gmail.com','F',18,'8279358224'
exec usp_Insert_Patient 'Harshit Yadav','harshit.yadav@yahoo.com','M',17,'7020662921'

go

select * from Hospital
select * from Medicine
select * from License
select * from Doctor
select * from [User]
select * from Patient

select * from Feedback
