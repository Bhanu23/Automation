﻿using System;
using System.Collections.Generic;

namespace DoctorDiary.DataAccessLayer.Models
{
    public partial class Prescription
    {
        public string PatientId { get; set; }
        public string DoctorId { get; set; }
        public string MedicineName { get; set; }
        public string Slot { get; set; }
        public double Quantity { get; set; }
        public DateTime Date { get; set; }

        public Doctor Doctor { get; set; }
        public Patient Patient { get; set; }
    }
}
