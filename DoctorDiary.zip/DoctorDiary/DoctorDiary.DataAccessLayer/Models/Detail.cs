﻿using System;
using System.Collections.Generic;

namespace DoctorDiary.DataAccessLayer.Models
{
    public partial class Detail
    {
        public string PatientId { get; set; }
        public string DoctorId { get; set; }
        public string Remark { get; set; }
        public string Meds { get; set; }
        public string Reference { get; set; }

        public Doctor Doctor { get; set; }
        public Patient Patient { get; set; }
    }
}
