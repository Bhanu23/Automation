﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DoctorDiaryMVC.Models;
using DoctorDiaryMVC.Repository;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using Microsoft.AspNetCore.Http;
using DoctorDiary.DataAccessLayer;
using AutoMapper;
using Microsoft.AspNetCore.Server.Kestrel.Core.Internal.Http;

namespace DoctorDiaryMVC.Controllers
{
    public class HomeController : Controller
    {
        IMapper mapper;
        IConfiguration _iconfiguration;
        DoctorDiaryRepository repository;
        public HomeController(IConfiguration iconfiguration, DoctorDiaryRepository repository, IMapper mapper)
        {
            _iconfiguration = iconfiguration;
            this.repository = repository;
            this.mapper = mapper;
        }
        public IActionResult Login()
        {

            try
            {
                return View();
            }
            catch (Exception ex)
            {

                return View("Error");
            }
        }
        public IActionResult Index()
        {
            try
            {
                return View();
            }
            catch (Exception)
            {

                return View("Error");
            }
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        //Action coresponding to Regsiter doctor view
        public IActionResult RegisterDoctor()
        {
            try
            {
                ViewBag.HospitalList = repository.GetHospitals();
                return View();
            }
            catch (Exception ex)
            {

                return View("Error");
            }
        }
        //action for saving doctors details
        public IActionResult SaveRegisterDoctor(IFormCollection frm,Models.RegisterDoctor objecto)
        {
            
            Models.Doctor obj = new Models.Doctor();
            try
            {
                string licenseId = /*frm["name"]*/ objecto.LicenseId;
                string emailId = /*frm["email"]*/objecto.EmailId;
                string password = /*frm["pass"]*/objecto.Password;
                //string conpassword = /*frm["re_pass"]*/objecto.Con_Password;
                if (!repository.CheckEmail(emailId, 'D'))
                {
                    TempData["Message"] = "Email";
                    return Redirect("RegisterDoctor");
                }
                string hospitalName = frm["hospitalId"]/*objecto.HospitalName*/;
                ServiceRepository serviceRepository = new ServiceRepository(_iconfiguration);
                HttpResponseMessage response = serviceRepository.GetResponse("api/License/GetLicense?licenseId=" + licenseId);
                response.EnsureSuccessStatusCode();
                Models.License license = response.Content.ReadAsAsync<Models.License>().Result;
                if (license == null)
                {
                    TempData["Message"] = "License";
                    return Redirect("RegisterDoctor");

                }
                obj.DoctorName = license.DoctorName;
                obj.Gender = license.Gender;
                obj.LicenseId = license.LicenseId;
                obj.SpecializationName = license.SpecializationName;
                obj.Dob = license.Dob;
                int issuedYear = license.Lid.Year;
                int currentYear = DateTime.Now.Year;
                int experience= currentYear - issuedYear;
                obj.Experience = experience;
                obj.EmailId = emailId;
                obj.HospitalId = repository.GetHospitalId(hospitalName);
                var status=repository.RegisterDoctor(mapper.Map<DoctorDiary.DataAccessLayer.Models.Doctor>(obj));
                var status1 = repository.AddUser(emailId, password, "D");
                if (status && status1)
                {
                    ViewBag.Message = "Doctor";
                    return View("Login");
                }
                    
                else
                    return RedirectToAction("Error","Home");
            }
            catch (Exception ex)
            {

                return View("Error");
            }
        }
        //Action corresponding to Register patient view
        public IActionResult RegisterPatient()
        {
            try
            {
                return View();
            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        //save details of registered patient
        public IActionResult SaveRegisterPatient(Models.RegisterPatient patient,IFormCollection frm)
        {
            try
            {
                int currentYear = DateTime.Now.Year;
                int dob = patient.DOB.Year;
                int age = currentYear - dob;
                if (!repository.CheckEmail(patient.EmailId, 'P'))
                {   
                    TempData["Message"] = "Email";
                    return Redirect("RegisterPatient");
                }
               
                    var status = repository.RegisterPatient(patient.Name, patient.EmailId,frm["gender"] , age, patient.PhoneNumber);
                var status1 = repository.AddUser(patient.EmailId, patient.Password, "P");
                if(status && status1)
                {
                    ViewBag.Message = "Patient";
                    return View("Login");
                }
                else
                {
                    return View("Error");
                }
            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        //A bridge view 
        public IActionResult Bridge()
        {
            return View();
        }
        // checking role between doctor patient
        public IActionResult CheckRole(Models.Login login)
        {
            try
            {
                string emailId = login.EmailId;
                string passwoed = login.Password;
                string role = repository.ValidateUser(emailId, passwoed);
                if (role == "D")
                {
                    HttpContext.Session.SetString("email", emailId);
                    return RedirectToAction("Home","Doctor");
                }
                else if(role=="P")
                {
                    HttpContext.Session.SetString("email", emailId);
                    return RedirectToAction("Home","Patient");
                }
                else if(role=="User not found")
                {
                    ViewBag.Message = role;
                    return View("Login");
                }
                else if(role== "Password not found")
                {
                    ViewBag.Message = role;
                    return View("Login");
                }
                else
                {
                    return View("Error");
                }
            }
            catch (Exception)
            {

                return View("Error");
            }
        }

        [HttpGet]
        public IActionResult Logout()
        {
            //FormsAuthentication.SignOut();
            HttpContext.Session.Remove("email");
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home");
        }
    }
}
