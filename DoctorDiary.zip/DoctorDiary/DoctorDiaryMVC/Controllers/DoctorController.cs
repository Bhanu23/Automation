﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using AutoMapper;
using DoctorDiary.DataAccessLayer;
using DoctorDiaryMVC.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace DoctorDiaryMVC.Controllers
{
    public class DoctorController : Controller
    {
        DoctorDiaryRepository repository;
        IMapper mapper;
        public DoctorController(DoctorDiaryRepository repository,IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }
        public IActionResult Home()
        {
            try
            {   
                if(HttpContext.Session.GetString("email")==null)
                    return RedirectToAction("Login", "Home");
                return View();
            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        public IActionResult DoctorDetails()
        {
            try
            {
                var emailId = HttpContext.Session.GetString("email");
                if (emailId == null)
                    return RedirectToAction("Login", "Home");
                ViewBag.Slots = repository.GetDoctorSlot(emailId);
                var doctor = repository.GetDoctorDetails(emailId);
                return View(mapper.Map<Models.Doctor>(doctor));
            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        public IActionResult UpdateDoctorDetails(Models.Doctor doc,IFormCollection frm)
        {
            try
            {
                if (DateTime.Now.DayOfWeek.ToString() != "Monday")
                {
                    TempData["Message"] = "day";
                    return Redirect("DoctorDetails");
                }
                else
                {
                    var status = repository.UpdateDoctorDetail(doc.DoctorId, frm["morslot"], frm["eveslot"]);
                    if (status)
                    {
                        TempData["Message"] = "Update";
                        return Redirect("Home");
                    }
                    else
                        return View("Error");
                }
             
            }
            catch (Exception)
            {

                return View("Error");
            }
        }
    }
}