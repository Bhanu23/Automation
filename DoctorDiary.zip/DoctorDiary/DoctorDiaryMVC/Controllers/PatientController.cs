﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using DoctorDiary.DataAccessLayer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DoctorDiaryMVC.Controllers
{
    public class PatientController : Controller
    {
        DoctorDiaryRepository repository;
        IMapper mapper;
        public PatientController(DoctorDiaryRepository repository, IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }
        public IActionResult Home()
        {
            return View();
        }
        public IActionResult PatientDetails()
        {
            var emailId = HttpContext.Session.GetString("email");
            var patient = repository.GetPatientDetails(emailId);
            return View(mapper.Map<Models.Patient>(patient));
        }

        public IActionResult UpdatePatientDetails(Models.Patient patient, IFormCollection frm)
        {
            try
            {
                var status = repository.UpdatePatientDetail(patient.PatientId, frm["Contact"]);
                if (status)
                {
                    TempData["Message"] = "Update";
                    return View("Home");
                }
                else
                    return View("Error");
            }
            catch (Exception)
            {

                return View("Error");
            }
        }
        public IActionResult BookAppointment(string specializationName)
        {
            try
            {
                List<string> specialization = repository.GetSpecialization();
                ViewBag.Specialization = specialization;
                List<Models.SearchDoctor> list = new List<Models.SearchDoctor>();
                var doctors = repository.GetDoctor(specializationName);
                foreach (var item in doctors)
                {
                    list.Add(new Models.SearchDoctor {
                        DoctorId=item.DoctorId,
                        DoctorName = item.DoctorName,
                        SpecializationName = item.SpecializationName,
                        Experience = item.Experience,
                        HospitalName = repository.GetHospitalName(item.HospitalId),
                        Rating = repository.GetRatings(item.DoctorId)
                    });
                }
                return View(list);
            }
            catch (Exception)
            {

                throw;
            }

        }
        public IActionResult PatientBookAppointment(Models.SearchDoctor doctor)
        {
            try
            {
                ArrayList list = repository.GetHospitalAddressPhone(doctor.HospitalName);
                ViewBag.Message = list;
                return View(doctor);
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}